<?php
require('../globals/header.php');
require('../classes/Product.php');

$prod = new Product();

$allproduct = $prod -> showProductCard();
?>

<main>
    <div class="container shop">
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <!-- Example -->
            <!-- <div class="col">
                <div class="card" onclick="location.href='hi.html';">
                    <img src="../assets/images/hero1.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Shoe No 1</h5>
                        <p class="card-text">This is a details with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                    </div>
                </div>
            </div> -->

            <!-- Real function -->
            <?php foreach ($allproduct as $product): ?>
            <div class="col">
                <div class="card">
                    <img src="../assets/images/<?php echo $product['product_name'];?>.jpg" class="card-img-top" alt="..." onclick="location.href='product-details.html';">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $product['product_name'];?></h5>
                        <b class="card-text"><?php echo $product['brand'];?><br>
                        RM<?php echo $product['unit_price'];?></b>
                    </div>
                </div>
            </div>
            <?php endforeach ?>
        </div>
    </div>
</main>
<?php require('../globals/footer.php'); ?>