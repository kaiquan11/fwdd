<?php require('../globals/header.php') ?>
    <a href="default.html" id="to-top"></a> 

    <main class="" style="width: 100%; margin:0; max-width: max-content;">

        <section data-parallax="scroll" data-image-src="../assets/images/hero1.jpg" id="hero" class="p-5">
            <article id="hero-text" class="text-light">
                <object data="../assets/images/step_up.svg" class="img-fluid" id="svg-title"></object>
                <br><br>
                <h1 id="subhero1" >Steadfast</h1>
                <h1 id="subhero2">Unparalleled</h1>
                <p id="subHero" style="margin-top: 2%; opacity: 0;">Giving rise to budding talents.</p>
            </article>
            <button id="heroBtn" class="su-btn" style="opacity: 0;" onclick="window.location.href='product-page.php'">Shop Now</button>
        </section>

        <section class="container-lg mt-5 "  id="gallery">
            <div data-id="0" data-desc="" class="tall-photo" style="background-image: url(../assets/images/gallery4.jpg);"></div>
            <div class="quote">
                <blockquote>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sint, debitis!</blockquote>
                <figcaption>- someone</figcaption>
            </div>
            <div data-id="1" data-desc="" class="regular-photo" style="background-image: url(../assets/images/gallery3.jpg);"></div>
            <div data-id="2" data-desc="" class="wide-photo" style="background-image: url(../assets/images/gallery2.jpg);"></div>
            <div data-id="3" data-desc="" class="tall-photo" style="background-image: url(../assets/images/gallery1.jpg);"></div>
            <div data-id="4" data-desc="" class="wide-photo" style="background-image: url(../assets/images/gallery5.jpg);"></div>
            <div class="quote">
                <blockquote>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</blockquote>
                <figcaption>- someone</figcaption>
            </div>

        </section>
        

        <section id="intro" class="container-fluid mt-3 text-center">

            <div class="row align-items-center text-light" style="background-color: #73628a;">
                <figure class="col-12 my-auto col-md-5">
                    <img src="../assets/images/intro_image.jpg" style="height: 100%; width: 100%" alt="">
                </figure>
                <article class="col-12 p-4 col-md-7">
                    <h3>Find the Perfect Gift</h3>
                    <p class="mt-2">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Alias totam accusantium deserunt quaerat voluptas at rem repudiandae, numquam temporibus quis.</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium, reprehenderit culpa veritatis laboriosam est earum.</p>
                    <button class="su-btn mt-2">Explore Gifts</button>
                </article>
            </div>

        </section>

        <section id="slider" class="container-fluid overflow-hidden gx-0">
            <div class="row">
                <div class="col-12 col-md-6">
                    <div id="image-slider" class="splide">
                        <div class="splide__track">
                            <ul class="splide__list">
                                <li class="splide__slide" data-index="0">
                                    <img src="../assets/images/slider1.jpg"  class="img-fluid">
                                </li>
                                <li class="splide__slide" data-index="1">
                                    <img src="../assets/images/slider2.jpg" data-id="23" class="img-fluid">
                                </li>
                                <li class="splide__slide" data-index="2">
                                    <img src="../assets/images/slider3.jpg" class="img-fluid">
                                </li>
                            </ul>
                        </div>
                      </div>
                </div>
                <article class="col-12 col-md-6 gx-0" id="nike-lineup">
                    <h2 style="height: 10vh; align-items: center; display: flex;">The Nike Lineup</h2>
                    <div id="slide-shoe-name" class="nike-name" data-name=""></div>
                    <div id="slide-shoe-desc" class="nike-desc" data-pro-desc=""></div>
                </article>
            </div>
        </section>

        <section id="brands" class="container-lg" style="margin-top: 5%;">
            <article id="brands-text" style="font-size: 3.5rem; font-weight: bold; text-align: center;">
                Featuring over &nbsp; <span id="brands-no">30</span> &nbsp; Brands to Choose from.
            </article>

            <div class="row gap-5" style="margin-top: 5%;">
                <div class="col brand">
                    <img src="../assets/images/Nike-Logo.png" alt="">
                </div>
                <div class="col brand">
                    <img src="../assets/images/adidas_logo.png" alt="">
                </div>
                <div class="col brand">
                    <img src="../assets/images/Puma-Logo.png" alt="">
                </div>
            </div>
            <div class="row gap-5" style="margin-top: 10%;">
                <div class="col brand">
                    <img src="../assets/images/Converse_logo.svg.png" alt="">
                </div>
                <div class="col brand">
                    <img src="../assets/images/Reebok-Logo-Transparent.png" alt="">
                </div>
            </div>
        </section>
        
    </main>

    <?php include('../globals/footer.php') ?>


    <!-- <script src="./node_modules/animejs/lib/anime.js"></script>
    <script src="./node_modules/@splidejs/splide/dist/js/splide.min.js"></script>

    <script src="./node_modules/jquery-parallax.js/parallax.min.js"></script>

    <script type="text/javascript" src="js/index.js"></script>

</body>
</html> -->