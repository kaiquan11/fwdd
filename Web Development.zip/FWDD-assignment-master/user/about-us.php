<?php require('../globals/header.php') ?>

    <div class="about-section">
        <h1>About Step Up</h1>
        <p>Some text about who we are and what we do.</p>
        <p>Resize the browser window to see that this page is responsive by the way.</p>
        </div>

        <h2 class="h2-title" style="text-align:center">Step Up Team</h2>
        <div class="row">
        <div class="column">
            <div class="card">
            <img src="../assets/images/founder.jpg" alt="Jane" style="width:100%">
            <div class="container">
                <h2>Jenny Lopez</h2>
                <p class="title">Founder</p>
                <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                <p>JennyLop@stepup.com</p>
            </div>
            </div>
        </div>

        <div class="column">
            <div class="card">
            <img src="../assets/images/CEO.jpg" alt="Mike" style="width:100%">
            <div class="container">
                <h2>Chris Handsome</h2>
                <p class="title">CEO</p>
                <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                <p>ChrisHS@stepup.com</p>
            </div>
            </div>
        </div>

        <div class="column">
            <div class="card">
            <img src="../assets/images/cofounder.jpg" alt="John" style="width:100%">
            <div class="container">
                <h2>Chad Giga</h2>
                <p class="title">Co-Founder</p>
                <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                <p>chad@stepup.com</p>
            </div>
            </div>
        </div>
    </div>

<?php require('../globals/footer.php'); ?>