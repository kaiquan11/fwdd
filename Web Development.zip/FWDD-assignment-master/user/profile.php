<?php
    require('../globals/header.php');
    require('../classes/Customer.php');

    $cus = new Customer();
    $username = $_SESSION['username'];

    $getCusInfo = $cus -> showCustomerInfo($username);
    $getCusStat = $cus -> showCustomerAccStat($getCusInfo['user_id']);

    if(isset($_POST['update-details'])) { 
        if ($getCusInfo['user_password'] == $_POST['password']) {
            if ($_POST['passwordEdit']=="") {
                $_POST['passwordEdit']=$getCusInfo['user_password'];
            }
            $cus -> cusUpdateInfo($_POST['userIDEdit'], $_POST['nameEdit'], $getCusInfo['username'], $_POST['passwordEdit'], $_POST['accountStatus']);
        } else {
            echo '<script>alert("Incorrect Password")</script>';
        }
    }

    if(isset($_POST['delete-customer'],$_POST['confirm-delete'])) {
        $cus -> deleteCustomer($_POST['idToDelete']);
        $_POST = array();
        session_unset();
        session_destroy();
        header('location: ../signup-signin/sign-in.php');
    }
?>
<main>
    <div class="container pf">
        <div class="col">
            <div class="card">
                <div class="rounded-top text-white d-flex flex-row" style="background-color: #000; height:200px">
                    <div class="ms-4 mt-5 d-flex flex-column" style="width: 150px;">
                        <img src="../assets/images/face.jpg" class="rounded-circle img-fluid img-thumbnail mt-4 mb-2" style="width: 150px; z-index: 1">

                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-outline-dark" style="z-index: 1;" data-bs-toggle="modal" data-bs-target="#editProfile">
                            Edit profile
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="editProfile" tabindex="-1" aria-labelledby="editProfileLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="POST" action="profile.php">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Edit Profile</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- Email -->
                                            <label for="email" class="form-label">Email</label>
                                            <input type="email" class="form-control mb-3 shadow-none" id="email" name="emailEdit" value="<?php echo $getCusInfo['email']; ?>" disabled readonly>

                                            <!-- Username -->
                                            <label for="username"  class="form-label">Username</label>
                                            <input type="text" class="form-control mb-3 shadow-none" id="username" name="usernameEdit" value="<?php echo $getCusInfo['username']; ?>" disabled readonly>
                                            <ul class="mb-3">
                                            </ul>
                                            
                                            <!-- Name -->
                                            <label for="f_name"  class="form-label">Name</label>
                                            <input type="text" class="form-control mb-3 shadow-none" required id="f_name" name="nameEdit" value="<?php echo $getCusInfo['first_name']; ?>">
                                            <ul class="mb-3">
                                            </ul>
                                            
                                            <!-- Old Password -->
                                            <label for="password" class="form-label">Current Password</label>
                                            <input type="password" name="password" class="form-control shadow-none" placeholder="Enter new password" required id="password">
                                            <ul class="mb-3">
                                            </ul>

                                            <!-- New Password -->
                                            <label for="new_password" class="form-label">New Password</label>
                                            <input type="password" name="passwordEdit" class="form-control shadow-none" placeholder="Enter new password" id="new_password" pattern="[a-zA-Z0-9_@?&]{7,}">
                                            <ul class="mb-3">
                                            <li class="form-text">Passwords must be at least 8 characters long</li>
                                            <li class="form-text">Passwords can only contain these characters: _ @ ? &</li>
                                            </ul>

                                            <input type="hidden" value="<?php echo $getCusInfo['user_id']; ?>" name="userIDEdit" id="userID">
                                            <input type="hidden" value="<?php echo $getCusStat['account_activated']; ?>" name="accountStatus" id="account-activated">
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary" name="update-details" id="change">Edit</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ms-3" style="margin-top: 130px;">
                    <h5><?php echo $getCusInfo['first_name']; ?></h5>
                    </div>
                </div>
                <div class="card-body p-4 text-black" style="margin-top: 75px">
                    <div class="mb-5">
                        <p class="lead fw-normal mb-3">About Me</p>
                        <div class="row mb-3">
                            <label for="username2" class="col-sm-3 col-form-label">Username:</label>
                            <div class="col-sm-9">
                                <input class="form-control" type="text" value="<?php echo $getCusInfo['username']; ?>" id="username2" disabled readonly>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="password2" class="col-sm-3 col-form-label">Password</label>
                            <div class="col-sm-9">
                                <input class="form-control" type="password" value="<?php echo $getCusInfo['user_password']; ?>" id="password2" disabled readonly>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="email2" class="col-sm-3 col-form-label">Email</label>
                            <div class="col-sm-9">
                                <input class="form-control" type="text" value="<?php echo $getCusInfo['email']; ?>" id="email2" disabled readonly>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="date2" class="col-sm-3 col-form-label">Date joined:</label>
                            <div class="col-sm-9">
                                <input class="form-control" type="text" value="<?php echo $getCusInfo['date_joined']; ?>" id="date2" disabled readonly>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteAccount">
                        Delete Account
                    </button>
                    <form class="modal fade" id="deleteAccount" action="profile.php" method ="POST">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content p-3">
                                <div class="modal-header">
                                    <h4 class="modal-title">Delete this user?</h4>
                                </div>
                                <div class="modal-body" id="userDetailsDelete">
                                    <p>Do you wish to delete this Account? Deleted account cannot be recovered. All data in this account will be removed.</p>

                                    <input class="form-check-input" type="checkbox" id="confirm-delete" name="confirm-delete">
                                    <label class="form-check-label mb-3" for="confirm-delete">Yes, I fully understand the consequences of my action.</label>

                                    <button type="submit" style="width: 6rem;" id="cus-delete" name="delete-customer" class="btn btn-outline-danger mx-auto my-3 d-block"><i class="bi bi-trash-fill">&nbsp;</i>Delete</button>

                                    <input type="hidden" value="<?php echo $getCusInfo['user_id']; ?>" name="idToDelete" id="userIDDel">
                                </div>
                            </div>
                        </div>
                    </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php require('../globals/footer.php'); ?>