
<div style="height: 10vh; width: 100%; background-color: black; color: white; text-align: center; padding-top: 1%; margin-top: 10%;">
    &copy;Step Up - 2022
</div>

<script src="../js/jquery-3.6.0.js"></script>

<script src="../js/bootstrap.bundle.min.js"></script>

<script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

<script src="../node_modules/animejs/lib/anime.js"></script>

<script src="../node_modules/@splidejs/splide/dist/js/splide.min.js"></script>

<script src="../node_modules/jquery-parallax.js/parallax.min.js"></script>

<script type="text/javascript" src="../js/index.js"></script>

</body>
</html>