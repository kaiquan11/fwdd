<?php 

    $conn = mysqli_connect('localhost', 'root', "", "fwdd_assignment");

    if(!$conn):
        echo 'database cnnection error' . mysqli_connect_error();
    endif;

?>