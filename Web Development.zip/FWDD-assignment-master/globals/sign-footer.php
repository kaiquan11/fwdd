                    <!-- Login button -->
                    <div class="d-grid gap-2 col-6 mx-auto">
                        <button type="submit" class="btn" name="<?php if ($curPageName === "sign-in.php") { echo "log"; } else {echo "reg"; }?>"><?php if ($curPageName === "sign-in.php") { echo "Log In"; } else { echo "Register"; }?></button>
                    </div>

                </form>
    </main>
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="../js/bootstrap.bundle.min.js"></script>

    <script>
        function showPassword() {
            var x = document.getElementById("psw");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
            }
        function showCfmPassword() {
            var x = document.getElementById("cfm_psw");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
    </script>
    
</body>

</html>