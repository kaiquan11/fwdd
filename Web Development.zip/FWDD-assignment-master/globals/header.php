<?php
  session_start();
  if ($_SESSION['success'] != "You have logged in successfully") {
    header('location: ../signup-signin/sign-in.php');
  }

  require('../globals/dbConnect.php');
  $curPageName = substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);

  if(isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header('location: ../signup-signin/sign-in.php');
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Step Up</title>
    <!-- Google css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">

    <!-- Bootstrap css -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <?php if ($curPageName=="about-us.php") {?>
    <link href="../css/about-us.css" rel="stylesheet">
    <?php } else {?>
    <link href="../css/user.css" rel="stylesheet">
    <?php } ?>
    <?php if ($curPageName!="about-us.php") {?>
      <link rel="icon" type="image/x-icon" href="../favicon/favicon.ico">

      <link href="https://fonts.googleapis.com/css2?family=Archivo+Narrow:wght@500&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css2?family=Archivo+Narrow:wght@500&family=Port+Lligat+Slab&display=swap" rel="stylesheet">

      <link href="../css/bootstrap.min.css" rel="stylesheet">

      <link rel="stylesheet" href="../node_modules/@splidejs/splide/dist/css/splide.min.css">

      <link href="../css/index.css" rel="stylesheet">
    <?php } ?>
</head>
<body>
  <!-- Nav bar -->
  <nav class="navbar sticky-top navbar-expand-lg navbar-dark <?php if ($curPageName === "profile.php") { echo "nav-pf"; }?>">
    <div class="container-fluid">
    <a class="navbar-brand" href="default.php">Step Up  </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarScroll">
        <ul class="navbar-nav me-auto my-2 my-lg-0">
          <li class="nav-item <?php if ($curPageName != "profile.php") { echo "g-nav"; } else { echo "pf-nav"; }?>">
            <a class="nav-link" href="default.php">Home</a>
          </li>
          <li class="nav-item <?php if ($curPageName != "profile.php") { echo "g-nav"; } else { echo "pf-nav"; }?>">
            <a class="nav-link <?php if ($curPageName === "product-page.php") { echo "active"; }?>" href="product-page.php">Shop</a>
          </li>
          <li class="nav-item <?php if ($curPageName != "profile.php") { echo "g-nav"; } else { echo "pf-nav"; }?>">
            <a class="nav-link" href="about-us.php">About Us</a>
          </li>
        </ul>
        <?php if ($_SESSION['success'] == "You have logged in successfully") { ?>
          <ul class="ms-auto navbar-nav">
            <li class="nav-item <?php if ($curPageName != "profile.php") { echo "g-nav"; } else { echo "pf-nav"; }?>">
              <a class="nav-link <?php if ($curPageName === "profile.php") { echo "active"; }?>" href="profile.php">Profile</a>
            </li>
            <li class="nav-item <?php if ($curPageName != "profile.php") { echo "g-nav"; } else { echo "pf-nav"; }?>">
              <a class="nav-link" href="#">Shopping cart</a>
            </li>
          </ul>
          <form class="d-flex" action="<?php echo $curPageName ?>" id="logout" method="GET">
            <button class="btn btn-outline-light" type="submit" name="logout">Log Out&nbsp;
              <i class="bi bi-box-arrow-right" style="font-size: 1.2rem;"></i>
            </button>
          </form>
        <?php } ?>

      </div>
    </div>
  </nav>
