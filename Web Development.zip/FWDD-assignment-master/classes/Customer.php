<?php 

class Customer {

    public function showCustomerInfo($username) {
        global $conn;

        $query = "SELECT * FROM users WHERE username = '$username'";

        $result = mysqli_query($conn, $query);

        $cusInfo = mysqli_fetch_assoc($result);

        return $cusInfo;
    }

    public function showCustomerAccStat($cusId) {
        global $conn;

        $queryCusAcc = "SELECT account_activated FROM customer WHERE customer_id = '$cusId'";

        $result = mysqli_query($conn, $queryCusAcc);

        $cusStat = mysqli_fetch_assoc($result);

        return $cusStat;
    }


    public function showCustomerList($name, $accountStatus) {
        
        global $conn;

        if($accountStatus == '' || $accountStatus == 2) {
            $selectQuery = "SELECT customer.customer_id, users.username, users.email, users.date_joined, customer.account_activated FROM users JOIN customer ON customer.customer_id = users.user_id";

        } else if($accountStatus == 0 ) {
            $selectQuery = "SELECT customer.customer_id, users.username, users.email, users.date_joined, customer.account_activated FROM users JOIN customer ON customer.customer_id = users.user_id WHERE users.username LIKE '%{$name}%' AND customer.account_activated = 0";

        } else if ($accountStatus == 1) {
            $selectQuery = "SELECT customer.customer_id, users.username, users.email, users.date_joined, customer.account_activated FROM users JOIN customer ON customer.customer_id = users.user_id WHERE users.username LIKE '%{$name}%' AND customer.account_activated = 1";
        }


        $result = mysqli_query($conn, $selectQuery);

        $customers = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $customers;
    }


    public function getUnverifiedUsers() {

        global $conn;

        $selectQuery = "SELECT COUNT(account_activated) AS Deactivated FROM customer WHERE account_activated = 0";

        $result = mysqli_query($conn, $selectQuery);

        $customers = mysqli_fetch_assoc($result);

        mysqli_free_result($result);

        return $customers;
    }

    
    public function cusUpdateInfo($cusID, $f_name, $username, $password, $accountStatus) {

        global $conn;

        $updateQuery = "UPDATE users u JOIN customer c ON u.user_id = c.customer_id SET u.username = '$username', u.first_name = '$f_name', u.user_password = '$password', c.account_activated = '$accountStatus' WHERE u.user_id = '$cusID'";

        if(!mysqli_query($conn, $updateQuery)) {
            echo "<script>alert('failed')</script>";
        } 

        echo !mysqli_query($conn, $updateQuery)? "<script>alert('Update attempt failed. Please try again later')</script>" : "<script>alert('Customer details updated. Changes will be made within 24 hours.')</script>";

    }


    public function updateDetails($cusID, $email, $username, $password, $accountStatus) {

        global $conn;

        $updateQuery = "UPDATE users u JOIN customer c ON u.user_id = c.customer_id SET u.username = '$username', u.email = '$email', u.user_password = '$password', c.account_activated = '$accountStatus' WHERE u.user_id = '$cusID'";

        if(!mysqli_query($conn, $updateQuery)) {
            echo "<script>alert('failed')</script>";
        } 

        echo !mysqli_query($conn, $updateQuery)? "<script>alert('Update attempt failed. Please try again later')</script>" : "<script>alert('Customer details updated. Changes will be made within 24 hours.')</script>";

    }


    public function addCustomer($name, $email, $username, $password, $accountStatus) {
            // echo "<script>alert(\"hello\")</script>";
        global $conn;

        $insertQueryUsers = "INSERT INTO users (username, first_name, user_password, email) VALUES ('$username', '$name', '$password', '$email')";

        if(mysqli_query($conn, $insertQueryUsers)) {

            echo "<script>alert(\"User table upadated\")</script>";

            $lastID = mysqli_insert_id($conn);

            $insertQueryCustomers = "INSERT INTO customer (customer_id, account_activated) VALUES ($lastID, $accountStatus)";

            if(mysqli_query($conn, $insertQueryCustomers)) {
                echo "<script>alert('Customer table updated')</script>";
            }
        };

    }


    // foreign key table is set to cascade on delete
    public function deleteCustomer($cusID) {

        global $conn;

        $deleteQueryUser = "DELETE FROM users WHERE user_id = $cusID";

        mysqli_query($conn, $deleteQueryUser);

    }

    public function getRecentJoins() {

        global $conn;

        $selectQuery = "SELECT * FROM users WHERE user_id in (SELECT customer_id FROM customer) ORDER BY user_id DESC LIMIT 5";

        $result = mysqli_query($conn, $selectQuery);

        $recentCustomers = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $recentCustomers;
    }


    public function getSubs() {

        global $conn;

        $selectQuery = "SELECT type, COUNT(type) as number FROM subscription GROUP BY type";

        $result = mysqli_query($conn, $selectQuery);

        $subCount = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $subCount;
    }

    public function getLatestSub() {
        global $conn;

        $selectQuery = "SELECT u.first_name, s.date_subscribed FROM users u JOIN subscription s WHERE u.first_name = (SELECT first_name FROM users WHERE user_id = s.user_id) ORDER BY s.date_subscribed DESC LIMIT 1";

        $result = mysqli_query($conn, $selectQuery);

        $latestSub = mysqli_fetch_assoc($result);

        return $latestSub;
    }



}

?>