<?php 

class Order {

    public function getAllOrders($conn) {

        $selectQuery = "SELECT * FROM orders";

        $result = mysqli_query($conn, $selectQuery);

        $orders = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $orders;
    }

    public function getPendingOrders($searchCriteria) {

        global $conn;

        $selectQueryAll = "SELECT * FROM orders WHERE order_status = 0";

        $selectQueryStatus = "SELECT * FROM orders WHERE order_status = 0 AND staff_assigned is null";

        $selectQueryDate = "SELECT * FROM orders WHERE order_status = 0 ORDER BY date_ordered DESC";

        $resultAll = mysqli_query($conn, $selectQueryAll);

        $pendingOrdersCount = mysqli_num_rows($resultAll);

        if($searchCriteria == "" || $searchCriteria == "default") {

            $resultAll = mysqli_query($conn, $selectQueryAll);
    
            $pendingOrders = mysqli_fetch_all($resultAll, MYSQLI_ASSOC);

        } else if($searchCriteria == "unassigned") {

            $resultStatus = mysqli_query($conn, $selectQueryStatus);

            $pendingOrders = mysqli_fetch_all($resultStatus, MYSQLI_ASSOC);

        } else if($searchCriteria == "order-date") {

            $resultDate = mysqli_query($conn, $selectQueryDate);

            $pendingOrders = mysqli_fetch_all($resultDate, MYSQLI_ASSOC);

        }

        return array($pendingOrdersCount, $pendingOrders);
    }
    

    public function getCompletedOrders() {

        global $conn;

        $selectQuery = "SELECT * FROM orders WHERE order_status = 1";

        $result = mysqli_query($conn, $selectQuery);

        $completedOrdersCount = mysqli_num_rows($result);

        $completedOrders = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return array($completedOrdersCount, $completedOrders);
    }


    public function updateOrder($orderStatus, $staffAssigned, $orderID) {

        global $conn;

        $updateQuery = "UPDATE orders SET order_status = '$orderStatus', staff_assigned = '$staffAssigned' WHERE order_id = '$orderID'";

        mysqli_query($conn, $updateQuery);


    }


    public function getItemsSold($conn) {

        $selectQuery = "SELECT product.product_name, SUM(order_item.quantity) as number_sold FROM product JOIN order_item ON product.product_id = order_item.product_id GROUP BY product.product_name LIMIT 3";

        $result = mysqli_query($conn, $selectQuery);

        $itemsSold = mysqli_fetch_all($result, MYSQLI_ASSOC);

        return $itemsSold;
    }

}


?>