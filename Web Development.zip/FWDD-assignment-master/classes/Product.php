<?php 

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

class Product {

    public function showProductCard() {
        
        global $conn;

        $query = "SELECT * FROM product";


        $result = mysqli_query($conn, $query);

        $product = mysqli_fetch_all($result, MYSQLI_ASSOC);

        // mysqli_free_result($result);

        return $product;
    }


    public function addProduct($productName, $price, $brand) {

        global $conn;

        $filename = $_FILES['thumbnail']['name'];
        $tempname = $_FILES['thumbnail']['tmp_name'];
        $folder = '../assets/images/' . $filename;

        $insertQuery = "INSERT INTO product (product_name, brand, unit_price) values ('$productName', '$brand', $price)";

        mysqli_query($conn, $insertQuery);

        if(move_uploaded_file($tempname, $folder)) {
            echo "<script>alert('Product image uploaded.')</script>";
        } else {
            echo "<script>alert('Product image could not be uploaded')</script>";
        }
    }
    

    public function updateProduct($ID, $newPrice) {

        global $conn;

        $updateQuery = "UPDATE product SET unit_price = $newPrice WHERE product_id = $ID";

        if(!mysqli_query($conn, $updateQuery)) {
            echo "<script>alert('Error! Either the product ID is not found or the is a server error. Please try again.')</script>";
        } else {
            echo "<script>alert('Product price updated.')</script>";
        }

    }

}

?>