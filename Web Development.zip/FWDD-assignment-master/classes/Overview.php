<?php 

    class Overview {

        public function getOrderCount() {

            global $conn;

            $selectQuery = "SELECT * FROM orders";

            $result = mysqli_query($conn, $selectQuery);
    
            $orderCount = mysqli_num_rows($result);
    
            return $orderCount;
        }


        public function getCustomerCount() {

            global $conn;

            $selectQuery = "SELECT * FROM users JOIN customer WHERE users.user_id = customer.customer_id";

            $result = mysqli_query($conn, $selectQuery);

            $customerCount = mysqli_num_rows($result);

            return $customerCount;
        }


        public function getProductCount() {

            global $conn;

            $selectQuery = "SELECT * FROM product";

            $result = mysqli_query($conn, $selectQuery);

            $productCount = mysqli_num_rows($result);

            return $productCount;
        }


    }

?>