<?php require('sign.php'); ?>
<?php require('../globals/sign-header.php'); ?>

<form action="sign-in.php" method="post" >
    <!-- Username -->
    <div class="row gy-2 gx-3 align-items-center mb-3">
        <label for="username" class="form-label">Username</label>
        <div class="col-9">
            <input type="text" class="form-control" id="username" placeholder="Username" name="username">
        </div>

    </div>
    <!-- Password -->
    <div class="row gy-2 gx-3 align-items-center mb-3">
        <label for="psw" class="form-label">Password</label>
        <div class="col-9">
            <input type="password" class="form-control" id="psw" placeholder="Password" name="psw">
        </div>
        <div class="col-auto">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="shwpsw" onclick="showPassword()">
                <label class="form-check-label" for="shwpsw"> Show </label>
            </div>
        </div>
    </div>

<?php require('../globals/sign-footer.php'); ?>
