<?php
session_start();

// Initialize variables
$username = "";
$f_name = "";
$password = "";
$cfm_password = "";
$email = "";
$errors = array();

// Connect database
$db = mysqli_connect('localhost','root','','fwdd_assignment');

// Register users
if (isset($_POST['reg'])) {

    // Receive all inputs
    $username = mysqli_real_escape_string($db, $_POST["username"]);
    $f_name = mysqli_real_escape_string($db, $_POST["first-name"]);
    $password = mysqli_real_escape_string($db, $_POST["psw"]);
    $cfm_password = mysqli_real_escape_string($db, $_POST["cfm_psw"]);
    $email = mysqli_real_escape_string($db, $_POST["email"]);
    $accountStatus = "0";

    // Validation
    if(empty($username)) { array_push($errors, "Username is required"); }
    if(empty($f_name)) { array_push($errors, "First name is required"); }
    if(empty($password)) { array_push($errors, "Password is required"); }
    if(empty($email)) { 
        array_push($errors, "Email is required"); 
    } else {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            array_push($errors, "Invalid Email Format");
        }
    }
    if($password != $cfm_password) { array_push($errors, "Password not match"); }

    // Check database to make sure username and email not registered
    $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
    $result = mysqli_query($db, $user_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) {
        if ($user['username'] === $username) {
            array_push($errors, "Username already exists");
        } 
        if ($user['email'] === $email) {
            array_push($errors, "Email already exists");
        }
    }

    if (count($errors) == 0) {
        // Encrypt password
        // $password = md5($password);

        $queryUsers = "INSERT INTO users (username, first_name, user_password, email) VALUES ('$username', '$f_name', '$password', '$email')";
        
        if(mysqli_query($db, $queryUsers)) {

            $lastID = mysqli_insert_id($db);

            $queryCustomers = "INSERT INTO customer (customer_id, account_activated) VALUES ($lastID, $accountStatus)";
            if(mysqli_query($db, $queryCustomers)) {
                header('location: sign-in.php');
            }
        };
    }
}

// Login users
if (isset($_POST['log'])) {
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['psw']);

    if (empty($username)) {
        array_push($errors, "Username is required");
    }

    if (empty($password)) {
        array_push($errors, "Password is required");
    }

    if (count($errors) == 0) {
        // Customer Account
        // $password = md5($password);
        $query = "SELECT * FROM users WHERE username='$username' AND user_password='$password' AND user_id in (SELECT customer_id FROM customer)";

        $results = mysqli_query($db, $query);

        if (mysqli_num_rows($results) == 1) {
          $_SESSION['username'] = $username;
          $_SESSION['success'] = "You have logged in successfully";
          // Location need set to homepage after log in
          header('location: ../user/default.php');
        }
        
        // Staff Account
        elseif (mysqli_num_rows($results) == 0) {
            // $password = md5($password);
            $query = "SELECT u.*, s.* FROM users u JOIN staff s WHERE u.username='$username' AND u.user_password='$password' AND u.user_id = s.staff_id ";

            $results = mysqli_query($db, $query);
            $staffDet = mysqli_fetch_array($results);

            if (mysqli_num_rows($results) == 1) {
                $_SESSION['username'] = $username;

                $role = $staffDet['access_level'] == '1' ? "Admin" : "Clerk";
                
                $_SESSION['access_level'] = $role;
                $_SESSION['success'] = "You have logged in successfully";
                
                
                header('location: ../admin/overview.php');
            }
        }
        
        if (mysqli_num_rows($results) == 0){
            array_push($errors, "Wrong username/password combination");
        }
    }
}

?>
