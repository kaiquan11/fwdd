<?php require('sign.php') ?>
<?php require('../globals/sign-header.php'); ?>

<form action="sign-up.php" method="post">

    <!-- Email -->
    <div class="mb-3">
        <label for="email" class="form-label">Email address</label>
        <input type="email" class="form-control" id="email" placeholder="email@mail.com" name="email">
    </div>

    <!-- Username -->
    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" placeholder="Username" name="username" pattern="[a-zA-Z0-9_.]{1,20}">
    </div>
    <ul class="mb-3">
        <li class="form-text">Username must not be more than 20 characters long</li>
        <li class="form-text">Username can only contain these characters: _ .</li>
    </ul>


    <!-- Username -->
    <div class="mb-3">
        <label for="first-name" class="form-label">First Name</label>
        <input type="text" class="form-control" id="first-name" placeholder="First Name" name="first-name">
    </div>
    
    <!-- Password -->
    <div class="row gy-2 gx-3 align-items-center mb-3">
        <label for="psw" class="form-label">Password</label>
        <div class="col-9">
            <input type="password" class="form-control" id="psw" placeholder="Password" name="psw" pattern="[a-zA-Z0-9_@?&]{7,}">
        </div>
        <div class="col-auto">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="shwpsw" onclick="showPassword()">
                <label class="form-check-label" for="shwpsw"> Show </label>
            </div>
        </div>
    </div>
    <ul class="mb-3">
        <li class="form-text">Passwords must be at least 8 characters long</li>
        <li class="form-text">Passwords can only contain these characters: _ @ ? &</li>
    </ul>


    <!-- Confirm Password -->
    <div class="row gy-2 gx-3 align-items-center mb-3">
        <label for="cfm_psw" class="form-label">Confirm Password</label>
        <div class="col-9">
            <input type="password" class="form-control" id="cfm_psw" placeholder="Confirm Password" name="cfm_psw" pattern="[a-zA-Z0-9_@?&]{7,}">
        </div>
        <div class="col-auto">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" value="" id="shwcfm_psw" onclick="showCfmPassword()">
                <label class="form-check-label" for="shwcfm_psw"> Show </label>
            </div>
        </div>
    </div>

<?php require('../globals/sign-footer.php'); ?>