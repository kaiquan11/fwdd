<?php 

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    include('../admin/includes/admin-navigation.php');
    require('../classes/Orders.php');


    $orders = new Order();

    $searchCriteria = "";

    if(isset($_GET['search-order'])) {
        $searchCriteria = $_GET['sortBy'];
    }

    // show pending orders based on search criterion
    $pending = $orders -> getPendingOrders($searchCriteria);
    $pendingOrdersList = $pending[1];
    $pendingOrderCount = $pending[0];

    $unassignedCount = 0;
    foreach($pendingOrdersList as $unassigned) {
        if(is_null($unassigned['staff_assigned'])) {
            $unassignedCount++;
        }
    }


    // show all completed orders
    $completed = $orders -> getCompletedOrders();
    $completedOrdersList = $completed[1];
    $completedOrderCount = $completed[0];


    if(isset($_POST['update-order'])) {
        $orders -> updateOrder($_POST['order-status'], $_POST['assigned-staff'], $_POST['ID']);

    }


?>

<!-- use mysqli_num_rows to display the number of orders -->
    <section class="container-fluid p-3 mt-5">

        <article id="order-summary" class="container-lg shadow">

            <div class="row p-3" style="background-color: #ffd3f3;background-image: linear-gradient(0deg, #ffd3f3 0%, #dee7e9 100%);">
                <div class="col-12 text-center">
                    <h2>Total Orders:</h2>
                    <h1 class="jetbrains-font"><?php echo $pendingOrderCount + $completedOrderCount ?></h1>
                </div>
            </div>

            <div class="row">
                <div class="col p-4" style="background-color: #FBAB7E; background-image: linear-gradient(62deg, #FBAB7E 0%, #F7CE68 100%);">
                    <p class=" text-start fs-1">Pending Orders:</p>
                    <p class=" jetbrains-font text-center" style="font-size: 5rem;"><?php echo $pendingOrderCount ?></p>
                    <hr style="height: 2px;">
                    <div class="row d-flex flex-column flex-lg-row">
                        <h3 class="col">Assigned: <?php echo $pendingOrderCount - $unassignedCount ?></h3>
                        <h3 class="col">Unassigned: <?php echo $unassignedCount ?></h3>
                    </div>
                </div>
                <div class="col p-4" style="background-color: #85FFBD; background-image: linear-gradient(45deg, #85FFBD 0%, #FFFB7D 100%);">
                    <p class=" text-start fs-1">Completed Orders:</p>
                    <p class=" jetbrains-font text-center" style="font-size: 5rem;"><?php echo $completedOrderCount ?></p>
                </div>
            </div>
        </article>


        <section id="filters" class="container-fluid mt-5">
            <form action="<?php $_SERVER['PHP_SELF'] ?>" method="GET">
                <div class="row">
                    <div class="col-6">
                        <select name="sortBy" id="" class="form-select">
                            <option value="default">Default View</option>
                            <option value="unassigned">Unassigned</option>
                            <option value="order-date">Order Date</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <button class="btn btn-outline-secondary" type="submit" name="search-order">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </div>
            </form>
        </section>


        <h1 class="mt-5">Pending Orders</h1>
        
        <section id="pending-orders" class="cards-grid mt-3">

        <?php foreach ($pendingOrdersList as $pendingOrder): ?>
        
            <article data-bs-toggle="modal" data-bs-target="#view-order" data-id='<?php echo $pendingOrder['order_id'] ?>' <?php echo is_null($pendingOrder['staff_assigned']) ? "class='card card-unassigned'" : "class='card card-pending'" ?>>

                <?php if(is_null($pendingOrder['staff_assigned'])): ?>

                <div class="card-overlay shadow text-light">
                <i class="bi bi-exclamation-diamond-fill"></i>
                <span>Unassigned Order</span>

                </div>

                <?php endif ?>

                <div class="card-body text-center">
                    <p class="fs-2 jetbrains-font">
                        <span class="p-3 bg-light shadow order-id"><?php echo $pendingOrder['order_id'] ?></span>
                    </p>
                    <br>
                    <p class="lead">Date ordered: <?php echo $pendingOrder['date_ordered'] ?></p>
                    <p style="font-size: 13px;" class="text-secondary">Customer: <?php echo $pendingOrder['customer'] ?></p>
                </div>
            </article>

        <?php endforeach; ?>


        </section>

        <hr class="mt-5" style="height: 2px;">

        <h1 style="margin-top: 60px;">Completed Orders</h1>

        <section id="completed-orders" class="cards-grid mt-3">

        <?php foreach($completedOrdersList as $completedOrder): ?>


            <article class="card card-completed" data-bs-toggle="modal" data-bs-target="#view-order" data-id='<?php echo $completedOrder['order_id'] ?>'>
                <div class="card-body text-center">
                    <p class="fs-2 jetbrains-font">
                        <span class="p-3 bg-light shadow order-id"><?php echo $completedOrder['order_id'] ?></span>
                    </p>
                    <br>
                    <p class="lead">Date ordered: <?php echo $completedOrder['date_ordered'] ?></p>
                    <p style="font-size: 13px;" class="text-secondary">Customer: <?php echo $completedOrder['customer'] ?></p>
                    
                </div>
            </article>
                

        <?php endforeach; ?>

        </section>

    </section>


    <!-- modal for viewing and editing order details -->
    <div class="modal fade" id="view-order">
        <div class="modal-dialog modal-lg">
            <div class="modal-content p-3">
                <div class="modal-header">
                    <h3 class="fw-bold modal-title">Order Details</h3>
                </div>
                <div class="modal-body" id="orderDetails">

                </div>
            </div>
        </div>
    </div>

<?php 

    include('../admin/includes/admin-footer.php');

?>