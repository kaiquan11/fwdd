<?php 
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    include('../admin/includes/admin-navigation.php');

    require('../globals/dbConnect.php');
    require('../classes/Product.php');

    $pro = new Product();

    $products = $pro -> showProductCard();

    if(isset($_POST['add-product'])) {
        $pro -> addProduct($_POST['product-name'], $_POST['product-price'], $_POST['product-brand']);
    }

    if(isset($_POST['update-product'])) {
        $pro -> updateProduct($_POST['update-product-id'], $_POST['update-product-price']);
    }

 ?>

    <section id="hero" class="text-center mt-5">
        <h1 class="mx-auto my-auto" style="text-decoration: underline;">Products</h1>
        <button id="add-product" data-bs-toggle="modal" data-bs-target="#product-upload-modal" class="mt-3 btn btn-outline-primary">Add new product</button>
        <button id="update" data-bs-toggle="modal" data-bs-target="#product-update-modal" class="mt-3 btn btn-warning">Update product price</button>
    </section>

    <section class="cards-grid" style="margin-top: 6%;">

        <?php foreach($products as $product): ?>

            <article class="card product-card" data-id="<?php echo $product['product_id'] ?>" style=" min-height: 250px; opacity: 0;" data-brand="<?php echo $product['brand'] ?>" data-price="<?php echo $product['unit_price'] ?>" data-name="<?php echo $product['product_name'] ?>" data-bs-toggle="modal" data-bs-target="#product-modal">
                <img src="../assets/images/<?php echo $product['product_name'] ?>.jpg" alt="">
                <div class="product-card-overlay"><?php echo $product['product_name'] ?></div>
            </article>

        <?php endforeach  ?>

    </section>

    <div class="modal fade" id="product-upload-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">List a new product</h5>
        </div>
  
        <form action="products.php" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control mb-3 shadow-none" required id="new-product-name" name="product-name">
                <label for="price" class="form-label">Price</label>
                <input type="text" class="form-control mb-3 shadow-none" required id="new-product-price" name="product-price">
                <label for="brand"  class="form-label">Brand</label>
                <input type="text" class="form-control shadow-none" required id="new-product-brand" name="product-brand">
                <label for="img"  class="form-label d-block mt-3">Select an image for this product</label>
                <input type="file" id="img" name="thumbnail">
                <button class="btn btn-outline-success mt-4 d-block ms-auto" id="addNewPro" name="add-product" type="submit"><i class="bi bi-send"></i>&nbsp;&nbsp;Submit</button>
            </div>
        </form>
 
        </div>
    </div>
    </div>

    <div class="modal fade" id="product-update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Update Price</h5>
        </div>
        <div class="modal-body">
            <form action="products.php" method="POST">
                <label for="name" class="form-label">Product ID:</label>
                <input type="text" class="form-control mb-3 shadow-none" required id="update-product-id" name="update-product-id">
                <label for="price" class="form-label">New Price:</label>
                <input type="text" class="form-control mb-3 shadow-none" required id="update-product-price" name="update-product-price">
                <button class="btn btn-outline-success mt-4 d-block ms-auto" id="updatePro" name="update-product" type="submit"><i class="bi bi-send"></i>&nbsp;&nbsp;Update changes</button>
            </form>
        </div>
 
        </div>
    </div>
    </div>

    
    <div class="modal fade" id="product-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Product Details</h5>
        </div>
        <div class="modal-body">
            <p id="product-id"></p>
            <p id="product-name"></p>
            <p id="brand"></p>
            <p id="product-price"></p>
        </div>
 
        </div>
    </div>
    </div>



<?php 

    include('../admin/includes/admin-footer.php')

?>