<?php 


    require('../admin/includes/admin-navigation.php');
    require('../classes/Customer.php');

    $cus = new Customer();

    $searchName = '';
    $saerchAccStat = '';

    if(isset($_GET['search'])) {
        $searchName = $_GET['cus-name'];
        $saerchAccStat = $_GET['account-stat'];
    }

    // display all customers based on search criteria
    $allCustomers = $cus -> showCustomerList($searchName, $saerchAccStat);

    // display number of unverified users
    $unverified_users = $cus -> getUnverifiedUsers();

    // get 5 most recent customers who joined
    $recentJoins = $cus -> getRecentJoins();

    $latestSub = $cus -> getLatestSub();


    if(isset($_POST)) {
        // update customer data
        if(isset($_POST['status'])) {
            $cus -> updateDetails($_POST['userID'], $_POST['email'], $_POST['username'], $_POST['password'], $_POST['accountStatus']);
        
            // add new customer record
        } else if(isset($_POST['statusAdd'])) {
            $cus -> addCustomer($_POST['name'], $_POST['email'], $_POST['username'], $_POST['password'], $_POST['accountStatus']);

            // delete existing customer record
        } else if(isset($_POST['statusDelete'])) {
            $cus -> deleteCustomer($_POST['userID']);
        }

    }



?>

    <section class="container-fluid p-3 mt-5 text-center text-lg-start">

    <div class="row">

    <h2 style="text-decoration: underline;">Customer Management</h2>
    <p class="text-secondary mt-2">
        Latest Subscription: <?php echo $latestSub['date_subscribed'] ?> - <?php echo $latestSub['first_name'] ?>
    </p>

        <ul class="list-group col-12 col-lg-8 mt-3" id="user-list">

            <form class="mb-3 container-md" action="<?php $_SERVER['PHP_SELF'] ?>" method="GET">

                <div class="row gap-2">

                    <div class="form-group col-12 col-md-5">
                        <input type="text" name="cus-name" placeholder="Username" class="form-control">
                    </div>

                    <div class="form-group col-12 col-md-5 ">
                        
                        <select name="account-stat" id="" class="form-select">
                            <option value="0">Unverified customers</option>
                            <option value="1">Verified customers</option>
                            <option value="2" selected>All customers</option>
                        </select>
                    </div>

                    <button class="mx-auto col-3 col-md-1 btn btn-outline-secondary" name="search">
                        <i class="bi bi-search"></i>
                    </button>
                </div>

            </form>

                <!-- table-like -->
                <?php if($unverified_users["Deactivated"] != 0) : ?>

                    <div class="p-3 mb-3" style="background-color: #f5ead0; color:#C67F06">
                        <i class="bi bi-exclamation-octagon">&nbsp;&nbsp;</i><?php echo $unverified_users["Deactivated"] ?> user(s) have yet to be verified.
                    </div>

                <?php endif ?>

                <span class="lead mb-3">Users list</span>

                <?php foreach ($allCustomers as $customer): ?>

                <li class="list-group-item">
                    <div class="container-fluid">
                        <div class="row align-items-center gap-1">
                            <div class="col-1 d-none d-sm-block">
                                <img src="../assets/images/person-circle.svg" alt="">
                            </div>
                            <div class="col">
                                <?php echo $customer['username'] ?>
                            </div>
                            <div class="col">

                                <?php if($customer['account_activated'] == 0): ?>
                                    <div class="p-2 rounded text-light" style="background: #f56298; width: fit-content;">Pending</div>

                                <?php else: ?>
                                    <div class="p-2 rounded" style="background: #c4e88e; width: fit-content;">Verified</div>

                                <?php endif; ?>

                            </div>
                            <div class="col d-flex flex-column flex-xl-row">
                                <button name="view" class="ms-2 btn btn-primary my-1 d-block d-lg-inline" data-id = '<?php echo $customer['customer_id'] ?>' data-bs-toggle = 'modal' data-bs-target = '#view-customer'>View</button>

                                <button class="ms-2 btn btn-warning my-1 d-block d-lg-inline" data-id = '<?php echo $customer['customer_id']?>' data-bs-toggle = 'modal' name="edit" data-bs-target = '#edit-customer'>Edit</button>

                                <button class="ms-2 btn btn-danger my-1 d-block d-lg-inline" name="delete" data-id = '<?php echo $customer['customer_id'] ?>' data-bs-toggle = 'modal' data-bs-target = '#delete-customer'>Delete</button>
                            </div>
                        </div>

                    </div>
                </li>

                <?php endforeach; ?>

            </ul>

        <div id="actions" class="col-12 col-lg-4 p-5">
            <ul class="list-group border border-1 border-dark" id="dash1">
                <li class="list-group-item">
                    <h4>Actions</h4>
                </li>
                <li class="list-group-item" data-bs-toggle = 'modal' data-bs-target='#addCustomer'>
                    <i class="bi bi-person-plus-fill"></i>
                    <span>Add user</span>
                </li>
                <li class="list-group-item" data-bs-toggle="modal" data-bs-target="#subscriptions">
                    <i class="bi bi-list-ol"></i>
                    <span>View Subscription Summary</span>
                </li>
            </ul>

            <ul class="list-group mt-4 border border-1 border-dark" id="dash2">
                <li class="list-group-item">
                    <h4>Recent activities</h4>
                    <span class="text-muted" style="font-size: 0.9rem;">5 most recent members</span>
                </li>
                <?php foreach($recentJoins as $recent): ?>

                <li class="list-group-item">
                    <?php echo $recent['username'] ?> <br> <span class="text-muted" style="font-size: small;">Date joined: <?php echo $recent['date_joined'] ?></span>
                </li>

                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    </section>

    <!-- modal for adding customer -->
    <form  class="modal fade" id="addCustomer">
        <div class="modal-dialog modal-lg">
            <div class="modal-content p-3" id="userID">
                <div class="modal-header">
                    <h5 class="modal-title">Add Customer</h5>
                </div>
                <div class="modal-body">
                    <div class="text-secondary mb-4">*The customer hereby agrees to the terms and conditions of the Step Up Membership Programme</div>

                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control mb-3 shadow-none" required id="name" name="nameAdd">

                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control mb-3 shadow-none" required id="email" name="emailAdd">

                    <label for="username"  class="form-label">Username</label>
                    <input type="text" class="form-control shadow-none" required id="username" name="usernameAdd" pattern="[a-zA-Z0-9_.]{1,20}">
                    <ul class="mb-3">
                        <li class="form-text">Username must not be more than 20 characters long</li>
                        <li class="form-text">Username can only contain these characters: _ .</li>
                    </ul>

                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="passwordAdd" class="form-control shadow-none" required id="password" pattern="[a-zA-Z0-9_@?&]{7,}">
                    <ul class="mb-3">
                        <li class="form-text">Passwords must be at least 8 characters long</li>
                        <li class="form-text">Passwords can only contain these characters: _ @ ? &</li>
                    </ul>

                    <label for="account-activated" class="form-label" >Account Status:</label>
                    <select name="account-statusAdd" id="account-activated" class="form-select mb-3">
                        <option value="0">Disable</option>
                        <option value="1">Enable</option>
                    </select>

                    <button class="btn btn-outline-success d-block ms-auto" id="addNewCus" name="add-customer" type="submit"><i class="bi bi-send"></i>&nbsp;&nbsp;Submit</button>
                </div>
            </div>
        </div>
    </form>

    <!-- modal for chart canvas -->
    <div class="modal fade"  id="subscriptions" autocomplete="off">
        <div class="modal-dialog modal-lg">
            <div class="modal-content p-3" id="userID">
                <div class="modal-header">
                    <h5 class="modal-title">Subscription Summary</h5>
                </div>
                <div class="modal-body p-4" id="sub-details">
                    <canvas id="subs"></canvas>
                </div>
                
            </div>
        </div>
    </div>

    <!-- modal for viewing customer details -->
    <div class="modal fade " id="view-customer">
        <div class="modal-dialog modal-lg">
            <div class="modal-content p-3" id="userID">
                <div class="modal-header">
                    <h5 class="modal-title">Customer Information</h5>
                </div>
                <img src="../assets/images/person-circle.svg" width="35%" height="35%" role="img" class="img-fluid" alt="">
                <div class="modal-body" id="userDetails">
                
                </div>
            </div>
        </div>
    </div>


    <!-- modal/form for updating customer details -->
    <form class="modal fade"  id="edit-customer" autocomplete="off">
        <div class="modal-dialog modal-lg">
            <div class="modal-content p-3" id="userID">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Customer Details</h5>
                </div>
                <div class="modal-body" id="userDetailsEdit">

                </div>
                
            </div>
        </div>
    </form>

    <!-- modal for deleting customer account -->
    <form class="modal fade" id="delete-customer">
        <div class="modal-dialog modal-md">
            <div class="modal-content p-3">
                <div class="modal-header">
                    <h4 class="modal-title">Delete this user?</h4>
                </div>
                <div class="modal-body" id="userDetailsDelete">

                </div>
            </div>
        </div>
    </form>


<?php 

    require('../admin/includes/admin-footer.php')

?>