
<?php 
    require('../globals/dbConnect.php');
    session_start();

    if(isset($_GET['logout'])) {
        session_unset();
        session_destroy();
        header('location: ../signup-signin/sign-in.php');
    } 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="https://fonts.googleapis.com/css2?family=Island+Moments&family=Open+Sans&family=Roboto+Condensed&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Fjalla+One&family=Island+Moments&family=Open+Sans&family=Roboto+Condensed&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Fjalla+One&family=JetBrains+Mono:wght@300&family=Open+Sans&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">

    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <link href="../css/admin-nav.css" rel="stylesheet">

    <link href="../css/admin.css" rel="stylesheet">


</head>
<body>


    
    <nav class="navbar-def">
        <ul class="navbar-nav">


            <li class="nav-item">
                <a href="overview.php" class="nav-link">
                      <?php require('../assets/images/pie-chart-fill.svg') ?>
                    <span class="link-text">Overview</span>
                </a>
            </li>

            <?php if ($_SESSION['access_level'] == "Admin") { ?>
            <li class="nav-item">
                <a href="customers.php" class="nav-link">
                    <?php require('../assets/images/people-fill.svg') ?>                        
                    <span class="link-text">Customers</span>
                </a>
            </li>
            <?php } ?>

            <li class="nav-item">
                <a href="orders.php" class="nav-link">
                    <?php require('../assets/images/receipt.svg') ?>
                    <span class="link-text">Orders</span>
                </a>
            </li>

            <li class="nav-item">
                <a href="products.php" class="nav-link">
                    <?php require('../assets/images/shop.svg') ?>
                    <span class="link-text">Products</span>
                </a>
            </li>

        </ul>

    </nav>

    <main>

        <section id="account" class="text-end container-fluid" style="width: 100%;">
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>"  id="logout" method="GET">
                <button type="submit" name="logout" class="btn btn-outline-secondary">
                    Logout&nbsp;
                    <i class="bi bi-box-arrow-right" style="font-size: 1.2rem;"></i>
                </button>
            </form>
        </section>
        
