<?php 

    if(isset($_POST['cusID'])) {

        $cusID = $_POST['cusID'];

        $conn = mysqli_connect('localhost', 'root', "", "fwdd_assignment");

        if(!$conn):
            echo 'database cnnection error' . mysqli_connect_error();
        endif;

        $selectQuery = "SELECT user_id FROM users WHERE users.user_id = '$cusID'";

        $result = mysqli_query($conn, $selectQuery);

        $targetCus = mysqli_fetch_assoc($result);

        $targetCusID = $targetCus['user_id'];

        $details = "
        
        <p>Do you wish to delete user $targetCusID? Deleted users cannot be recovered. All orders associated with this customer will be removed.</p>

        <input class=\"form-check-input\" type=\"checkbox\" id=\"confirm-delete\">
        <label class=\"form-check-label mb-3\" for=\"confirm-delete\">Yes, I fully understand the consequences of my action.</label>

        <button type=\"submit\" style=\"width: 6rem;\" id=\"cus-delete\" name=\"delete-customer\" class=\"btn btn-outline-info mx-auto my-3 d-block\"><i class=\"bi bi-trash-fill\">&nbsp;</i>Delete</button>


        
        <input type=\"hidden\" value=\"$targetCusID\" name=\"cusToDelete\">
        
        ";

        echo $details;

    }

?>