<?php 

    if(isset($_POST['cusID'])) {

        $cusID = $_POST['cusID'];

        $conn = mysqli_connect('localhost', 'root', "", "fwdd_assignment");

        if(!$conn):
            echo 'database connection error' . mysqli_connect_error();
        endif;

        $selectQuery = "SELECT users.user_id, users.username, users.email, customer.account_activated FROM users JOIN customer ON customer.customer_id = users.user_id WHERE users.user_id = '$cusID'";

        $result = mysqli_query($conn, $selectQuery);

        $targetCus = mysqli_fetch_assoc($result);

        $email = $targetCus['email'];
        $username = $targetCus['username'];
        $accountStatus = $targetCus['account_activated'];
        $userID = $targetCus['user_id'];

        $details = "                    <label for=\"email\" class=\"form-label\">Email</label>
        <input type=\"email\" class=\"form-control mb-3 shadow-none\" required id=\"email\" name=\"emailEdit\" value=\"$email\">

        <label for=\"username\"  class=\"form-label\">Username</label>
        <input type=\"text\" class=\"form-control mb-3 shadow-none\" required id=\"username\" name=\"usernameEdit\" value=\"$username\" pattern=\"[a-zA-Z0-9_.]{1,20}\">
        <ul class=\"mb-3\">
        <li class=\"form-text\">Username must not be more than 20 characters long</li>
        <li class=\"form-text\">Usernmae can only contain these characters: _ .</li>
        </ul>

        <label for=\"password\" class=\"form-label\">Password</label>
        <input type=\"password\" name=\"passwordEdit\" class=\"form-control shadow-none\" placeholder=\"Enter new password\" required id=\"password\" pattern=\"[a-zA-Z0-9_@?&]{7,}\">
        <ul class=\"mb-3\">
        <li class=\"form-text\">Passwords must be at least 8 characters long</li>
        <li class=\"form-text\">Passwords can only contain these characters: _ @ ? &</li>
        </ul>


        <label for=\"account-activated\" class=\"form-label\" >Account Status:</label>
        <select name=\"account-statusEdit\" id=\"account-activated\" class=\"form-select mb-3\">
            <option value=\"0\">Disable</option>
            <option value=\"1\">Enable</option>
        </select>

        <button class=\"btn btn-outline-success d-block ms-auto\" name=\"update-details\" id=\"change\"><i class=\"bi bi-send\"></i>&nbsp;&nbsp;Submit</button>
        
        <input type=\"hidden\" value=\"$userID\" name=\"userIDEdit\" id=\"ID\">
        
        ";
        
        echo $details;

    }




?>