<?php 

    if(isset($_POST["cusID"])) {
        
        $cusID = $_POST['cusID'];
        // echo "<script>alert('hi')</script>";
        $conn = mysqli_connect('localhost', 'root', "", "fwdd_assignment");

        if(!$conn):
            echo 'database cnnection error' . mysqli_connect_error();
        endif;

        $selectQuery = "SELECT users.username, users.first_name, users.email, customer.account_activated FROM users JOIN customer ON users.user_id = customer.customer_id WHERE customer.customer_id = '$cusID'";

        $result = mysqli_query($conn, $selectQuery);

        $targetCus = mysqli_fetch_assoc($result);

        $name = $targetCus['first_name'];
        $username = $targetCus['username'];
        $email = $targetCus['email'];
        $account = $targetCus['account_activated'];

        $details =  "<p>Name:  $name</p>";
        $details .= " <p>Email:  $email </p>";

        if($targetCus['account_activated'] == 1) {
            $details .= "<p class=\"rounded me-auto\" style=\"background: #c4e88e;\">Account Status: $account</p>";
        } else {
            $details .= "<p class=\"rounded me-auto\" style=\"background: #f56298;\">Account Status: $account</p>";
        }


        $details .= "<p>Username: $username</p>";

         echo $details;
    }

?>

<!--  -->