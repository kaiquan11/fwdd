    
        <p class="text-end mt-5" style="font-size: 1.2rem;">
            <i class="bi bi-question-square-fill" ></i>
            &nbsp;Contact support
        </p>
    
    </main>

    <script src="../node_modules/animejs/lib/anime.min.js"></script>

    <script src="../js/bootstrap.bundle.min.js"></script>

    <script src="../js/jquery-3.6.0.js"></script>
    
    <script src="../js/admin.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js/dist/chart.min.js"></script>
   
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns/dist/chartjs-adapter-date-fns.bundle.min.js"></script>



</body>
</html>