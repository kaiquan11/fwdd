<?php 

if(isset($_POST['orderID'])) {

    $orderID = $_POST['orderID'];

    $conn = mysqli_connect('localhost', 'root', "", "fwdd_assignment");

    if(!$conn):
        echo 'database cnnection error' . mysqli_connect_error();
    endif;

    $selectQueryOrder = "SELECT orders.*, users.first_name FROM orders JOIN users ON orders.customer = users.user_id WHERE orders.order_id = '$orderID'";

    $resultOrder = mysqli_query($conn, $selectQueryOrder);

    $order = mysqli_fetch_assoc($resultOrder);

    $ID = $order['order_id'];
    $cus = $order['first_name'];
    $address = $order['delivery_address'];
    $orderDate = $order['date_ordered'];
    $staff = $order['staff_assigned'];
    $price = $order['total_price'];
    $orderStatus = $order['order_status'];

    $staffAssigned = "";

    if(is_null($staff)) {

        $staffAssigned = "<span class=\"p-2 rounded text-light bg-danger\">Unassigned</span>";

    } else {

        $selectQueryStaff = "SELECT username FROM users WHERE user_id = '$staff'";
        
        $resultStaff = mysqli_query($conn, $selectQueryStaff);

        $targetStaff = mysqli_fetch_assoc($resultStaff);

        $staffAssigned = $targetStaff['username'];
    }

    
    $selectQueryStaffList = "SELECT users.username, staff.staff_id FROM users JOIN staff ON staff.staff_id = users.user_id";

    $resultStaffList = mysqli_query($conn, $selectQueryStaffList);

    $staffList = mysqli_fetch_all($resultStaffList, MYSQLI_ASSOC);


    $staffOptions = "";

    foreach($staffList as $staffDet) {
        $staffOptions .= "<option value=$staffDet[staff_id]>$staffDet[username]</option>";
    }

    $selectQueryOrderItem = "SELECT oi.*, p.product_name FROM order_item oi JOIN product p WHERE oi.order_id = '$ID' AND oi.product_id = p.product_id";

    $resultsOrderItems = mysqli_query($conn, $selectQueryOrderItem);

    $orderItems = mysqli_fetch_all($resultsOrderItems, MYSQLI_ASSOC);

    $itemsList = "";
    $counter = 1;

    foreach($orderItems as $item) {
        $itemsList .= "<tr><td>$counter</td><td>$item[product_name]</td><td>$item[quantity]</td></tr>";
        $counter++;
    }
    

    $details = "
    <table class=\"table\">
        <thead>
            <th>Field</th>
            <th>Particulars</th>
        </thead>

        <tbody>
            <tr>
                <td>Order ID</td>
                <td>$ID</td>
            </tr>
            <tr>
                <td>Customer Name</td>
                <td>$cus</td>
            </tr>
            <tr>
                <td>Delivery Address</td>
                <td>$address</td>
            </tr>
            <tr>
                <td>Date Ordered</td>
                <td>$orderDate</td>
            </tr>
            <tr>
                <td>Staff Assigned</td>
                <td class=\"p-2\">$staffAssigned</td>
            </tr>
        </tbody>

    </table>
    
    <br>

    <p class=\"fs-5\"><u>Order items</u></p>
    <table class=\"mt-2 table table-striped\" id=\"order-items\">
        <thead>
            <tr>
                <th>No.</th>
                <th>Item</th>
                <th>Quantity</th>
            </tr>
        </thead>
        <tbody>
            $itemsList
        </tbody>
    </table>
    <br>

    ";

    $updateForm = "
    <form action=\"orders.php\" method=\"POST\" id=\"update-order\" class=\"p-5 border border-warning border-2\">
    <p class=\"fs-3\">Update Order</p>

    <label for=\"staff\" class=\"form-label\">Staff Assigned</label>
    <select name=\"assigned-staff\" id=\"staff\" class=\"form-select\">
        $staffOptions
    </select>

    <label for=\"status\" class=\"form-label mt-3\">Order Status</label>
    <select name=\"order-status\" id=\"status\" class=\"form-select\"> 
        <option value=\"0\">Pending</option>
        <option value=\"1\">Completed</option>
    </select>

    <input type=\"hidden\" value=\"$ID\" name=\"ID\">
    <br>

    <button class=\"d-block ms-auto btn btn-outline-success\" type=\"submit\" name=\"update-order\">Submit Changes</button>
</form>
    
    ";

    if($orderStatus == 0) {
        echo $details . $updateForm;
    } else {
        echo $details;
    }



}

?>