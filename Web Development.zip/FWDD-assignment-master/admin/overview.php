<?php 
    // session_start();
    include('../admin/includes/admin-navigation.php');
    require('../classes/Overview.php');

    $ov = new Overview();

    $orderCount = $ov -> getOrderCount();

    $customerCount = $ov -> getCustomerCount();

    $productCount = $ov -> getProductCount();
    
?>


    <section class="container-fluid p-3 mt-5 ">

        <article class="text-center" id="user-greet">
            <h1>Welcome back <?php echo $_SESSION['username'] ?></h1>
            <p class="text-secondary">Role: <?php echo $_SESSION['access_level'] ?></p>
        </article>


        <section id="summary" class="fs-3 p-2 d-flex flex-column gap-4 flex-lg-row mt-5">

            <article id="customers" onclick="window.location.href = 'customers.php'" class="flex-grow-1">
                
                <div class="go-corner">
                    <i class="bi bi-arrow-right arrow"></i>
                </div>
            
                <div class="text-center p-5">
                    <p>Customers</p>
                    <p class="fs-1 jetbrains-font"><?php echo $customerCount ?></p>
                </div>


            </article>


            <article id="orders" onclick="window.location.href = 'orders.php'" class="flex-grow-1">
            
                <div class="go-corner">
                    <i class="bi bi-arrow-right arrow"></i>
                </div>
                
                <div class="p-5  text-center">
                    <p>Orders</p>
                    <p class="fs-1 jetbrains-font"><?php echo $orderCount ?></p>
                </div>

            </article>

            <article id="products" class="flex-grow-1" onclick="window.location.href = 'products.php'">
            
                <div class="go-corner">
                    <i class="bi bi-arrow-right arrow"></i>
                </div>
                
                <div class="p-5 text-center">
                    <p>Products</p>
                    <p class="fs-1 jetbrains-font"><?php echo $productCount ?></p>
                </div>

            </article>

        </section>



        <section id="charts" class="row mt-5">

            <div id="canvas-demo" class="chart-space" >
                <h2 class="mb-4">Monthly Sales</h2>
                <canvas id="monthly-sales" ></canvas> 
            </div>

            <!-- required data: products that appear in order item, quantity of each product sold -->
            <div class="chart-space">
                <h2 class="mb-4">Product Popularity</h2>
                <canvas id="hot-selling"></canvas>
            </div>

        </section>

    </section>


<?php include('../admin/includes/admin-footer.php') ?>