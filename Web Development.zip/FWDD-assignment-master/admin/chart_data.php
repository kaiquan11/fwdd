<?php 

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

require('../classes/Orders.php');
require('../classes/Customer.php');
require('../globals/dbConnect.php');

$orders = new Order();
$cus = new Customer();

if(isset($_POST['sales'])) {

    
    $orderList = $orders -> getAllOrders($conn);

    $timeArray = array();
    $priceArray = array();

    foreach($orderList as $order) {
        array_push($timeArray, $order['date_ordered']);
        array_push($priceArray, $order['total_price']);
        // $timeArray[] = $order['date_ordered'];
        // $priceArray[] = $order['total_price'];
    }

    echo json_encode(array('time' => $timeArray, 'price' => $priceArray));

    exit();

} 

if(isset($_POST['items'])) {


    $itemsSold = $orders -> getItemsSold($conn);

    $items = array();
    $quantity = array();

    foreach($itemsSold as $itemSold) {
        array_push($items, $itemSold['product_name']);
        array_push($quantity, $itemSold['number_sold']);
    }

    echo json_encode(array('items' => $items, 'quantity' => $quantity));

    exit();
    
}

if(isset($_POST['subs'])) {

    $subs = $cus -> getSubs();

    $type = array();
    $count = array();

    foreach($subs as $sub) {
        array_push($type, $sub['type']);
        array_push($count, $sub['number']);
    }

    echo json_encode(array('type' => $type, 'count' => $count));

    exit();
}

?>