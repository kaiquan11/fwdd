
/// <reference path="../typings/globals/jquery/index.d.ts" />


var banner = document.getElementById('svg-title');


banner.addEventListener("load", function() {

    // @ts-ignore
    var svg = banner.contentDocument.querySelectorAll('path');
    
    var paths = new Array();
    
    for(var i = 0; i < svg.length; i++) {
        paths.push(svg[i])
    }

    anime({
        targets: paths,
        strokeDashoffset: [anime.setDashoffset, 0],
        easing: 'easeInOutSine',
        duration: 4000,        
    })

})


var subLink = document.getElementById('to-top')

subLink.onclick = (event) => {
    event.preventDefault()
    window.scrollTo(0, 0)
}

window.addEventListener('scroll', function() {

    if(document.body.scrollTop > 500 || document.documentElement.scrollTop > 500) {
        
        anime ({
            targets: subLink,
            translateY: '0.5%',
            duration: 200,
            easing: 'easeInOutSine', 
        })
    } else {

        anime ({
            targets: subLink,
            translateY: '-100%',
            duration: 200,
            easing: 'easeInOutSine',
        })
    }
})


var heroText1 = document.getElementById('subhero1')
var heroText2 = document.getElementById('subhero2')
var subHero = document.getElementById('subHero')
var heroBtn = document.getElementById('heroBtn') 

var heroTimeline = anime.timeline({
    easing: 'easeOutExpo',
    duration: 3000,
    delay: 1000
})

heroTimeline.add({
    targets: heroText1,
    opacity: 1,
    duration: 1000
}).add({
    targets: heroText2,
    opacity: 1,
    duration: 1000
}, '-=1000').add({
    targets: [subHero, heroBtn],
    opacity: 1,
    duration: 1000
}, '-=1000')


var galleryDesc = ["Maximum performance", 
                "Unrivaled style",
                "New in stores",
                "Top seller of the month",
                "A classic pick"];


var galleryPhotos = document.querySelectorAll('#gallery > div')

galleryPhotos.forEach(index => 
    index.addEventListener('mouseenter', function() {
        var i = this.dataset.id
        this.setAttribute("data-desc", galleryDesc[i])
    })    
)


var splide = new Splide( '.splide', {
    autoplay: true
} );

var sliderShoes = [
    ["Nike Red", "Perfect for all sorts of activities. The Nike Red is available in stores now!"],
    ["Nike White", "Introducing the pair of shoes that will provide you with the utmost comfort. Don't miss out on this revolutionary footwear!"],
    ["Nike Swift", "Move with style! The new Nike Swift will show the world how trendy you are."]
]

const slideShoeName = document.getElementById("slide-shoe-name")
const slideShoeDesc = document.getElementById("slide-shoe-desc")
// var activeSlide = document.getElementsByClassName('is-active')

splide.on('mounted', function() {
    slideShoeName.setAttribute("data-name", sliderShoes[0][0])
    slideShoeDesc.setAttribute("data-pro-desc", sliderShoes[0][1])
    slideShoeName.innerText = sliderShoes[0][0]
    slideShoeDesc.innerText = sliderShoes[0][1]
})

splide.mount()

splide.on('move', function(e) {

    var index = splide.index

    anime({
        targets: [slideShoeName, slideShoeDesc],
        keyframes: [
            {translateX: '200%'},
            {translateX: 0}
        ],
        duration: 1000,
        easing: 'easeInOutQuart'
    })

    setTimeout(function() {
        slideShoeName.innerText = sliderShoes[index][0]
        slideShoeDesc.innerText = sliderShoes[index][1]
    }, 500)

})


const brandsText = document.getElementById('brands-text')
const brandsNo = document.getElementById('brands-no')
const brandsImg = document.querySelectorAll('.brand')

window.addEventListener('scroll', playText)

function playText() {
    let dist = brandsText.getBoundingClientRect().top - window.innerHeight

    var brandsTextTimeline = anime.timeline({
        // duration: 5000,
        easing: 'easeInOutQuart'
    })

    if(dist < -400) {
        brandsTextTimeline.add({
            targets: brandsText,
            translateY: "0%",
            opacity: 1,
            duration: 1000
        }).add({
            targets: brandsNo,
            innerText: [0, 30],
            duration: 7000,
            round: 1,
        }, '-=2000').add({
            targets: brandsImg,
            opacity: 1,
            duration: 1000,
            delay: anime.stagger(200, {start: 0})
        }, '-=5000')



        window.removeEventListener('scroll', playText)
    }
}

