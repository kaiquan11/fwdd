/// <reference path="../typings/globals/jquery/index.d.ts" />



jQuery(function() {

    $('button[name=view]').click(function(e) {

        var cusID = $(this).data('id');

        $.ajax({
            url: '../admin/includes/customer-view-modal.php',
            method: 'POST',
            data: {cusID: cusID},
            success: function(data) {
                $("#userDetails").html(data);
                $("#view-customer").modal("show")

            }
        })

    })


    $('button[name=edit]').click(function(e) {

        var cusID = $(this).data('id');
        console.log(cusID);
        
        $.ajax({
            url: '../admin/includes/customer-edit-modal.php',
            method: 'POST',
            data: {cusID: cusID},
            success: function(data) {
                $("#userDetailsEdit").html(data);
                $("#edit-customer").modal("show")

            }
        })

    })


    $('#edit-customer').submit(function(e) {

        var cusID = $('input[name=userIDEdit]').val();
        var username = $('input[name=usernameEdit]').val();
        var email = $('input[name=emailEdit]').val();
        var password = $('input[name=passwordEdit]').val();
        var accountStatus = $('select[name=account-statusEdit]').val();

        $.ajax({
            url: '../admin/customers.php',
            method: 'POST',
            data: {
                status: 1,
                userID: cusID,
                username: username,
                email: email,
                password : password,
                accountStatus : accountStatus
            },
            success: function(data) {
                console.log('success');
            }
        })
    })


    $('#addCustomer').submit(function(e) {

        var name = $('input[name=nameAdd]').val();
        var username = $('input[name=usernameAdd]').val();
        var email = $('input[name=emailAdd]').val();
        var password = $('input[name=passwordAdd]').val();
        var accountStatus = $('select[name=account-statusAdd]').val();

        $.ajax({
            url: '../admin/customers.php',
            method: 'post',
            data: {
                'statusAdd': 1,
                'name': name,
                'username': username,
                'email': email,
                'password' : password,
                'accountStatus' : accountStatus
            },
            success: function(data) {
                console.log('success');

            }
        })
    })


// delete func
    $('button[name=delete]').click(function(e) {

        var cusID = $(this).data('id');

        $.ajax({
            url: '../admin/includes/customer-delete-modal.php',
            method: 'POST',
            data: {cusID: cusID},
            success: function(data) {
                $("#userDetailsDelete").html(data);
                $("#delete-customer").modal("show")

                $('#cus-delete').prop('disabled', true)

                $('#confirm-delete').on('click', function() {
                    if($(this).is(':checked')) {
                        $('#cus-delete').prop('disabled', false)
                    } else {
                        $('#cus-delete').prop('disabled', true)
                    }
                })

            }
        })

    })





    $('#delete-customer').submit(function(e) {

        var cusID = $('input[name=cusToDelete]').val();
        alert('Customer removed: ' + cusID);

        $.ajax({
            url: '../admin/customers.php',
            method: 'post',
            data: {
                'statusDelete': 1,
                'userID': cusID
            },
            success: function(data) {
                console.log('success');
            },
            error: function() {
                console.log('request failed')
            }
        })
    })



    $('.card').click(function() {

        var orderID = $(this).data('id');

        $.ajax({
            url: '../admin/includes/order-modal.php',
            method: 'POST',
            data: {orderID: orderID},
            success: function(data) {
                $('#orderDetails').html(data);
                $('#view-order').modal("show")
            }
        })
    })


    // ------- chart section

    $(document).ready(function() {
        // get data for monthly sales
        $.ajax({
            url: '../admin/chart_data.php',
            method: 'POST',
            data: {'sales': 1},
            dataType: 'json',
            success: function(data) {
                generateSalesChart(data.time, data.price);
                getItemData()
            }
        })
    })


    function getItemData() {

        $.ajax({
            url: '../admin/chart_data.php',
            method: 'POST',
            data: {'items': 1},
            dataType: 'json',
            success: function(data) {
                generateItemPopularityChart(data.items, data.quantity)
            }
        })
    }

    $(document).ready(function() {
        // get data on subscriptions
        $.ajax({
            url: '../admin/chart_data.php',
            method: 'POST',
            data: {'subs': 1},
            dataType: 'json',
            success: function(data) {
                generateSubChart(data.type, data.count)
            }
        })
    })


    function generateSubChart(category, data) {

        const myChart = document.getElementById('subs').getContext('2d');

        let subsChart = new Chart(myChart, {
            type: 'bar',
            data: {
                labels: category,
                datasets: [{
                    label: 'Number of subscriptions',
                    backgroundColor: ['#183642', '#313d5a', '#73628a'],
                    data: data
                }]
            }
        })
    }


    function generateItemPopularityChart(labels, data) {

        const myChart = document.getElementById('hot-selling').getContext('2d');

        let itemsChart = new Chart(myChart, {
            type: 'pie',
            data: {
                labels: labels,
                datasets: [{
                    backgroundColor: ['#183642', '#313d5a', '#73628a'],
                    label: 'Number sold (unit)',
                    data: data
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Top 3 hottest selling shoes'
                    }
                }
            }
        })
    }


    function generateSalesChart(xAxis, yAxis) {

        const myChart = document.getElementById('monthly-sales').getContext('2d');

        let salesChart = new Chart(myChart, {
            type: 'line',
            data: {
                labels: xAxis,
                datasets: [{
                    label: ['Total Price'],
                    lineTension: 0.5, //smooth curves
                    data: yAxis,
                    borderColor: "rgba(49, 61, 90, 1)",
                    fill: true,
                    borderJoinStyle: 'round',
                    pointBackgroundColor: "rgba(115, 98, 138, 1)",
                    pointerHoverRadius: 100
                }]
            },
            options: {
                scales: {
                    x: {
                        type: 'time',
                        time: {unit: 'month'},
                        title: {
                            display: true,
                            text: 'Month',
                        },
                        min: '2021-02-01'
                    },
                    
                    y: {
                        title: {
                            display: true,
                            text: 'Price(RM)',
                        },
                        min: 0
                    }
                }
            }
        })
    }

    let id = document.getElementById('product-id')
    let name = document.getElementById('product-name')
    let brand = document.getElementById('brand')
    let price = document.getElementById('product-price')
    
    $('.product-card').on('click', function() {
        
        let cardData = {
            product_name: $(this).data('name'),
            product_id: $(this).data('id'),
            brand: $(this).data('brand'),
            price: $(this).data('price')
        }

        id.innerText = "Product ID: " + cardData.product_id;
        name.innerText = "Name: " + cardData.product_name
        brand.innerText = "Brand: " + cardData.brand
        price.innerText = "Unit price(RM): " + cardData.price
    })

    
})

let productCards = document.querySelectorAll('.product-card')

anime({
    targets: productCards,
    opacity: 1,
    delay: anime.stagger(100)
})
